require('app/vendor');

import angular from 'angular';
import globalResources from 'app/src/global';

var app = angular.module('rentetoolApp', [globalResources]);
