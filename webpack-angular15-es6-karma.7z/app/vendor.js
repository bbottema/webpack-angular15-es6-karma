// wraps all requires that should be included in the separate vendor.js
// these requires can be done in our source where needed, but then they end up in our app.js

require('angular');
